/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   push_swap.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: orhaddao <orhaddao@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/12/21 19:33:22 by orhaddao          #+#    #+#             */
/*   Updated: 2023/12/30 17:30:44 by orhaddao         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

void	sort_list(t_list **a, t_list **b)
{
	int	lst_size;

	lst_size = ft_lstsize(*a);
	update_info(*a);
	if (is_sorted(*a) == 1)
		return ;
	if (lst_size == 1)
		return ;
	else if (lst_size == 2)
		sort_two(a);
	else if (lst_size == 3)
		sort_three(a);
	else if (lst_size == 4)
		sort_four(a, b);
	else if (lst_size == 5)
		sort_five(a, b);
	else
		big_list_sort(a, b);
}

int	main(int argc, char **argv)
{
	t_list	*a;
	t_list	*b;
	char	*str;

	a = NULL;
	b = NULL;
	str = concat_args(argc, argv);
	if (str[0] == '\0')
		return (0);
	if (check_rules(str) == 0)
		return(ft_error());
	printf("%s\n", str);
	fill_stack_a(&a, &str);
	sort_list(&a, &b);
	return (0);
}
