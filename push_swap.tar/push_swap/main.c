#include <stdio.h>
#include <unistd.h>

int main()
{
	printf("hello");
	write(1, "youssef\n", 8);
	return 0;
}