#!/bin/bash

# Define some colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[2;33m'
NC='\033[0m' # No Color

# Array of all permutations of 4 numbers
numbers=(
    "1 2 3 4"
    "1 2 4 3"
    "1 3 2 4"
    "1 3 4 2"
    "1 4 2 3"
    "1 4 3 2"
    "2 1 3 4"
    "2 1 4 3"
    "2 3 1 4"
    "2 3 4 1"
    "2 4 1 3"
    "2 4 3 1"
    "3 1 2 4"
    "3 1 4 2"
    "3 2 1 4"
    "3 2 4 1"
    "3 4 1 2"
    "3 4 2 1"
    "4 1 2 3"
    "4 1 3 2"
    "4 2 1 3"
    "4 2 3 1"
    "4 3 1 2"
    "4 3 2 1"
)

# Run push_swap with each permutation
for i in "${numbers[@]}"; do
    echo -e "${GREEN}Running push_swap with numbers: $i${NC}"
    push_swap_output=$(./push_swap $i | tr '\n' ' ')
    echo -e "${YELLOW}command => $push_swap_output${NC}"
    echo -e "${RED}Number of instructions: $(wc -w <<< "$push_swap_output")${NC}"
	 echo -e "================"
done