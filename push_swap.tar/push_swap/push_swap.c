/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   push_swap.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: orhaddao <orhaddao@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/12/21 19:33:22 by orhaddao          #+#    #+#             */
/*   Updated: 2023/12/28 12:24:33 by orhaddao         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"
#include <stdio.h>


int	main(int argc, char **argv)
{
	t_list	*a;
	t_list	*b;

	a = NULL;
	b = NULL;
	if (argc == 1 || (argc == 2 && argv[1] == NULL))
		return (0);
	argv++;
	if (argc == 2)
		argv = ft_split(argv[0], ' ');
	fill_stack_a(&a, argv);
	sort(&a, &b);
	return (0);
}
